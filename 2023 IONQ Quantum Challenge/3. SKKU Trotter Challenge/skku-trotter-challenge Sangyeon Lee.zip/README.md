Welcome to IonQ's Trotterization Challenge!

To get started, please fire up ``instruction_docs/index.html`` in your favorite web browser.